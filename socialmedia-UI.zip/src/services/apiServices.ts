import axios from "axios";

const backendUrl = "http://localhost:3000";

export type IApiData = {
  "status": boolean,
  "message": string,
  "data": object
}

const apiService = {

  logIn: async function (logInDetails: any) {

    try {
      const response = await axios.post(`${backendUrl}/user/login`, logInDetails, {
        headers: {
          'Accept': 'application/json, text/plain, */*',
          'Content-Type': 'application/json',
        },
      })

      if (response)
        return { "status": true, "data": response.data }

      return { "status": false, "message": "Unable to create user" }
    }
    catch (error) {
      console.log(error)
      return { "status": false, "message": "Unable to create file" }
    }
  },

  signUp: async function (signUpDetails: any) {

    try {
      const response = await axios.post(`${backendUrl}/user`, signUpDetails, {
        headers: {
          'Accept': 'application/json, text/plain, */*',
          'Content-Type': 'application/json',
        },
      })

      if (response)
        return { "status": true, "data": response.data }

      return { "status": false, "message": "Unable to create user" }
    }
    catch (error) {
      console.log(error)
      return { "status": false, "message": "Unable to create file" }
    }
  },

};



export default apiService;
