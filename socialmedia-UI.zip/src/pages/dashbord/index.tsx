import React from 'react'
import "./dashbord.css"
import Sidebar from '../../components/sidebar';

const Dashboard = () => {
  return (
    <div className='dashboard-parent'>
      <Sidebar />
      <div className='dashboard-section'></div>
    </div>
  )
}

export default Dashboard;