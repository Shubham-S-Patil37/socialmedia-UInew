import React from 'react'
import apiService from '../../services/apiServices'

const Home = () => {
  const onClick = () => {
    apiService.signUp()
  }

  return (
    <div>

    </div>
  )
}

export default Home;