import React from 'react'
import "./sidebar.css"

const Sidebar = () => {

  const sidebarItem = ["Feed", "Profile", "Upload", "Setting"]
  return (
    <div className='sidebar-parent'>
      <ul>
        {sidebarItem.map(ele =>
          <li>{ele}</li>
        )}
      </ul>
    </div>
  )
}
export default Sidebar;